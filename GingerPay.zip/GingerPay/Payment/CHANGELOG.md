Magento 2 1.0.0 
------------------------------   

# Changelog #

## Changes in version 1.0.0
+ Initial version
