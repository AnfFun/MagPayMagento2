<?php

namespace GingerPay\Payment\Redefiners\Controller;

use GingerPay\Payment\Model\Builders\ControllerCheckoutActionBuilder;

class ControllerCheckoutActionRedefiner extends ControllerCheckoutActionBuilder
{

}
