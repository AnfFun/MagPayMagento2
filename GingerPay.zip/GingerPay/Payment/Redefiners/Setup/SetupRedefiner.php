<?php

namespace GingerPay\Payment\Redefiners\Setup;

use GingerPay\Payment\Model\Builders\SetupBuilder;

class SetupRedefiner extends SetupBuilder
{

}
