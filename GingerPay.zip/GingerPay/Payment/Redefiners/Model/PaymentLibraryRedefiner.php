<?php
declare(strict_types=1);

namespace GingerPay\Payment\Redefiners\Model;

use GingerPay\Payment\Model\AbstractPayment;

class PaymentLibraryRedefiner extends AbstractPayment
{

}