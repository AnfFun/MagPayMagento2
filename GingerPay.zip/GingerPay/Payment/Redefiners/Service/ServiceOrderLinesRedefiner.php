<?php

namespace GingerPay\Payment\Redefiners\Service;

use GingerPay\Payment\Model\Builders\ServiceOrderLinesBuilder;

class ServiceOrderLinesRedefiner extends ServiceOrderLinesBuilder
{

}
