<?php

namespace GingerPay\Payment\Redefiners\Service;

require_once __DIR__.'/../../Model/Builders/ServiceOrderBuilder.php';

use GingerPay\Payment\Model\Builders\ServiceOrderBuilder;

class ServiceOrderRedefiner extends ServiceOrderBuilder
{

}