<?php

namespace GingerPay\Payment\Redefiners\Service;

use GingerPay\Payment\Model\Builders\TransactionBuilder;

class TransactionRedefiner extends TransactionBuilder
{

}

